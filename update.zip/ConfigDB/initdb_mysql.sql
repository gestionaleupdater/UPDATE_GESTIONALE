DROP TABLE IF EXISTS `tbUtenti`;
CREATE TABLE IF NOT EXISTS `tbUtenti` (
  `username` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `nome_cognome` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `lvl` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbUtenti`(`username`,`nome_cognome`,`password`,`numero`,`lvl`) VALUES('Antonio','Antonio Ciccarelli','anto2020','','0'),('Davide','Davide Zannetti','davide2020','3760661481','0'),('Denis','Denis Di Donato','denis2020','3518706820','0'),('Deposito','Deposito','d','','0'),('dmservice','dmservice','admin','','1'),('Daniele','Daniele Mosca','daniele2020','','0'),('Donato','Donato Tasiello','donato2020','','0'),('Dario','Dario Gamboni','dario2020','','0'),('Christian','Christian Tasiello','chri2020','','0');


DROP TABLE IF EXISTS `tbClienti`;
CREATE TABLE IF NOT EXISTS `tbClienti` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ragione_sociale` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `partita_iva` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `ragione_sociale` (`ragione_sociale`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `tbNegozi`;
CREATE TABLE IF NOT EXISTS `tbNegozi` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `negozio` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `indirizzo` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `numero` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `id_ragione_sociale` int(11) NOT NULL,
  `partita_iva` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `id_ragione_sociale` (`id_ragione_sociale`),
  CONSTRAINT `tbNegozi_ibfk_1` FOREIGN KEY (`id_ragione_sociale`) REFERENCES `tbClienti` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `tbRicambi`;
CREATE TABLE IF NOT EXISTS `tbRicambi` (
  `codice` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `marca` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `descrizione` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `prezzo` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`codice`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbRicambi`(`codice`,`marca`,`descrizione`,`prezzo`) VALUES('MPB396','OMEGA','ALBERINO GOMMATO 3''''','50.00'),('MPC818','OMEGA','BOCCOLA FLANGIATA','6.00'),('MPC821','OMEGA','MPC821','6.00'),('MPF100','OMEGA','CINGHIA DENTATA','15.00'),('MPF101','OMEGA','CINGHIA DENTATA TONDA','10.00'),('MPG0038','OMEGA','TESTINA TERMICA','284.00'),('MPM207B','OMEGA','CAVETTO FFC P. 1,25 (LUNGHEZZA 280MM - 28 VIE)','20.00'),('MPM398','OMEGA','CAVETTO FFC P. 1,25 (LUNGHEZZA 500MM -14 VIE)','20.00'),('MPQ057','OMEGA','MOTORE STEPPER','100.00'),('MPX0150','OMEGA','PORTA ROTOLO CON LEVA','10.00'),('MPZ528','OMEGA','FOTOCELLULA TESTA ALZATA CABLATA L=25CM','25.00'),('MPZ753B','OMEGA','INTERFACCIA STAMPANTE','120.00'),('MPZ769','OMEGA','GRUPPO ETICHETTATRICE LINERLESS VER. PLC/ASC','900.00'),('MPZ771','OMEGA','ASSIEME SENSORE A FORCHETTA','20.00'),('MPZ779A','OMEGA','ASSIEME ETICHETTATRICE VER. PL/AS/CS-P','850.00'),('MPZ797','OMEGA','CAVETTO MICROSWITCH CABLATO 27CM CASSETTO APERTO VER. PLC/ASC (PER ETICHETTATRICE CON COD. MPZ796)','10.00');

DROP TABLE IF EXISTS `tbSostituito`;
CREATE TABLE IF NOT EXISTS `tbSostituito` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `negozio` varchar(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `macchinario` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `matricola` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ext_username` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `codice_ricambi` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `data_sostituzione` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `garanzia` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `immagine` blob DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `ext_username` (`ext_username`),
  KEY `codice_ricambi` (`codice_ricambi`),
  CONSTRAINT `tbSostituito_ibfk_1` FOREIGN KEY (`ext_username`) REFERENCES `tbUtenti` (`username`),
  CONSTRAINT `tbSostituito_ibfk_2` FOREIGN KEY (`codice_ricambi`) REFERENCES `tbRicambi` (`codice`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `tbInventario`;
CREATE TABLE IF NOT EXISTS `tbInventario` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `quantita` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ext_username` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `codice_ricambi` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `ext_username` (`ext_username`),
  KEY `codice_ricambi` (`codice_ricambi`),
  CONSTRAINT `tbInventario_ibfk_1` FOREIGN KEY (`ext_username`) REFERENCES `tbUtenti` (`username`),
  CONSTRAINT `tbInventario_ibfk_2` FOREIGN KEY (`codice_ricambi`) REFERENCES `tbRicambi` (`codice`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `tbOrdini`;
CREATE TABLE IF NOT EXISTS `tbOrdini` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ext_username` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `codice_ricambi` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `quantita` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `accettato` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `ext_username` (`ext_username`),
  KEY `codice_ricambi` (`codice_ricambi`),
  CONSTRAINT `tbOrdini_ibfk_1` FOREIGN KEY (`ext_username`) REFERENCES `tbUtenti` (`username`),
  CONSTRAINT `tbOrdini_ibfk_2` FOREIGN KEY (`codice_ricambi`) REFERENCES `tbRicambi` (`codice`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `tbRitirato`;
CREATE TABLE IF NOT EXISTS `tbRitirato` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `macchinario` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `marca` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `modello` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `matricola` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `descrizione` varchar(8000) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `completato` varchar(1) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `username_ritirato` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `username_riparato` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_negozio` int(11) NOT NULL,
  `data_ritirato` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `data_riparato` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `username_ritirato` (`username_ritirato`),
  KEY `id_negozio` (`id_negozio`),
  CONSTRAINT `tbRitirato_ibfk_1` FOREIGN KEY (`username_ritirato`) REFERENCES `tbUtenti` (`username`),
  CONSTRAINT `tbRitirato_ibfk_2` FOREIGN KEY (`id_negozio`) REFERENCES `tbNegozi` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

