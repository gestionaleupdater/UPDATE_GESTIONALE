DROP TABLE tbSostituito;
DROP TABLE tbInventario;
DROP TABLE tbRitirato;
DROP TABLE tbOrdini;
DROP TABLE tbRicambi;
DROP TABLE tbNegozi;
DROP TABLE tbClienti;
DROP TABLE tbUtenti;