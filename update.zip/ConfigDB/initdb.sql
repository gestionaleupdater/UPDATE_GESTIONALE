		/*CREAZIONE TABELLE*/
								CREATE TABLE tbClienti 
								(
									Id              INTEGER  NOT NULL  PRIMARY KEY ,
									ragione_sociale VARCHAR (50) NOT NULL UNIQUE,
									partita_iva     VARCHAR (50) NOT NULL
								);

								CREATE GENERATOR GEN_TBCLIENTI_ID;

								SET TERM !! ;
								CREATE TRIGGER TBCLIENTI_BI FOR TBCLIENTI
								ACTIVE BEFORE INSERT POSITION 0
								AS
								DECLARE VARIABLE tmp DECIMAL(18,0);
								BEGIN
								  IF (NEW.ID IS NULL) THEN
									NEW.ID = GEN_ID(GEN_TBCLIENTI_ID, 1);
								  ELSE
								  BEGIN
									tmp = GEN_ID(GEN_TBCLIENTI_ID, 0);
									if (tmp < new.ID) then
									  tmp = GEN_ID(GEN_TBCLIENTI_ID, new.ID-tmp);
								  END
								END!!
								SET TERM ; !!


								CREATE TABLE tbUtenti 
								(
									username     VARCHAR (50) NOT NULL PRIMARY KEY,
									nome_cognome VARCHAR (50) NOT NULL,
									password     VARCHAR (50) NOT NULL,
									numero       VARCHAR (50),
									lvl          VARCHAR (10)
								);
								CREATE TABLE tbRicambi 
								(
									codice      VARCHAR (50) NOT NULL PRIMARY KEY,
									marca       VARCHAR (50) NOT NULL,
									descrizione VARCHAR (50) NOT NULL,
									prezzo      VARCHAR (50) NOT NULL
								);
								
								
								CREATE TABLE tbSostituito
								 (
									Id            INTEGER NOT NULL  PRIMARY KEY,
									negozio       VARCHAR (1000) NOT NULL,
									macchinario   VARCHAR (200) NOT NULL,
									matricola   VARCHAR (200) NOT NULL,
									ext_username   VARCHAR (50) NOT NULL,
									codice_ricambi VARCHAR (50) NOT NULL,
									data_sostituzione VARCHAR (20)   NOT NULL,
									garanzia VARCHAR (20)   NOT NULL,
									immagine BLOB,
									FOREIGN KEY (ext_username) REFERENCES tbUtenti (username),
									FOREIGN KEY (codice_ricambi) REFERENCES tbRicambi (codice)
								);
								
								CREATE GENERATOR GEN_TBSOSTITUITO_ID;

								SET TERM !! ;
								CREATE TRIGGER TBSOSTITUITO_BI FOR TBSOSTITUITO
								ACTIVE BEFORE INSERT POSITION 0
								AS
								DECLARE VARIABLE tmp DECIMAL(18,0);
								BEGIN
								  IF (NEW.ID IS NULL) THEN
									NEW.ID = GEN_ID(GEN_TBSOSTITUITO_ID, 1);
								  ELSE
								  BEGIN
									tmp = GEN_ID(GEN_TBSOSTITUITO_ID, 0);
									if (tmp < new.ID) then
									  tmp = GEN_ID(GEN_TBSOSTITUITO_ID, new.ID-tmp);
								  END
								END!!
								SET TERM ; !!
								
								
								CREATE TABLE tbInventario
								 (
									Id             INTEGER NOT NULL  PRIMARY KEY,
									quantita       VARCHAR (50) NOT NULL,
									ext_username   VARCHAR (50) NOT NULL,
									codice_ricambi VARCHAR (50) NOT NULL,
									FOREIGN KEY (ext_username) REFERENCES tbUtenti (username),
									FOREIGN KEY (codice_ricambi) REFERENCES tbRicambi (codice)
								);

								CREATE GENERATOR GEN_TBINVENTARIO_ID;

								SET TERM !! ;
								CREATE TRIGGER TBINVENTARIO_BI FOR TBINVENTARIO
								ACTIVE BEFORE INSERT POSITION 0
								AS
								DECLARE VARIABLE tmp DECIMAL(18,0);
								BEGIN
								  IF (NEW.ID IS NULL) THEN
									NEW.ID = GEN_ID(GEN_TBINVENTARIO_ID, 1);
								  ELSE
								  BEGIN
									tmp = GEN_ID(GEN_TBINVENTARIO_ID, 0);
									if (tmp < new.ID) then
									  tmp = GEN_ID(GEN_TBINVENTARIO_ID, new.ID-tmp);
								  END
								END!!
								SET TERM ; !!


								CREATE TABLE tbNegozi 
								(
									Id                 INTEGER   NOT NULL  PRIMARY KEY,
									negozio            VARCHAR (50)  NOT NULL,
									indirizzo          VARCHAR (100) NOT NULL,
									numero             VARCHAR (50)  NOT NULL,
									id_ragione_sociale INTEGER       NOT NULL,
									partita_iva        VARCHAR (50)  NOT NULL,
									FOREIGN KEY (id_ragione_sociale) REFERENCES tbClienti (Id)
								);

								CREATE GENERATOR GEN_TBNEGOZI_ID;

								SET TERM !! ;
								CREATE TRIGGER TBNEGOZI_BI FOR TBNEGOZI
								ACTIVE BEFORE INSERT POSITION 0
								AS
								DECLARE VARIABLE tmp DECIMAL(18,0);
								BEGIN
								  IF (NEW.ID IS NULL) THEN
									NEW.ID = GEN_ID(GEN_TBNEGOZI_ID, 1);
								  ELSE
								  BEGIN
									tmp = GEN_ID(GEN_TBNEGOZI_ID, 0);
									if (tmp < new.ID) then
									  tmp = GEN_ID(GEN_TBNEGOZI_ID, new.ID-tmp);
								  END
								END!!
								SET TERM ; !!

								CREATE TABLE tbRitirato 
								(
									Id                INTEGER    NOT NULL  PRIMARY KEY,
									macchinario       VARCHAR (50)   NOT NULL,
									marca             VARCHAR (50)   NOT NULL,
									modello           VARCHAR (50)   NOT NULL,
									matricola         VARCHAR (50)   NOT NULL,
									descrizione       VARCHAR (8000) NOT NULL,
									completato        VARCHAR (1)    NOT NULL,
									username_ritirato VARCHAR (50)   NOT NULL,
									username_riparato VARCHAR (50),
									id_negozio        INTEGER        NOT NULL,
									data_ritirato     VARCHAR (20)   NOT NULL,
									data_riparato     VARCHAR (20),
									FOREIGN KEY (username_ritirato) REFERENCES tbUtenti (username),
									FOREIGN KEY (id_negozio) REFERENCES tbNegozi (Id)
								);

								CREATE GENERATOR GEN_TBRITIRATO_ID;

								SET TERM !! ;
								CREATE TRIGGER TBRITIRATO_BI FOR TBRITIRATO
								ACTIVE BEFORE INSERT POSITION 0
								AS
								DECLARE VARIABLE tmp DECIMAL(18,0);
								BEGIN
								  IF (NEW.ID IS NULL) THEN
									NEW.ID = GEN_ID(GEN_TBRITIRATO_ID, 1);
								  ELSE
								  BEGIN
									tmp = GEN_ID(GEN_TBRITIRATO_ID, 0);
									if (tmp < new.ID) then
									  tmp = GEN_ID(GEN_TBRITIRATO_ID, new.ID-tmp);
								  END
								END!!
								SET TERM ; !!

								CREATE TABLE tbOrdini 
								(
									Id                INTEGER    NOT NULL  PRIMARY KEY,
									ext_username      VARCHAR (50)   NOT NULL,
									codice_ricambi    VARCHAR (50)   NOT NULL,
									quantita          VARCHAR (50)   NOT NULL,
									accettato         VARCHAR (10)   NOT NULL,
									FOREIGN KEY (ext_username) REFERENCES tbUtenti (username),
									FOREIGN KEY (codice_ricambi) REFERENCES tbRicambi (codice)
								);

								CREATE GENERATOR GEN_TBORDINI_ID;

								SET TERM !! ;
								CREATE TRIGGER TBORDINI_BI FOR TBORDINI
								ACTIVE BEFORE INSERT POSITION 0
								AS
								DECLARE VARIABLE tmp DECIMAL(18,0);
								BEGIN
								  IF (NEW.ID IS NULL) THEN
									NEW.ID = GEN_ID(GEN_TBORDINI_ID, 1);
								  ELSE
								  BEGIN
									tmp = GEN_ID(GEN_TBORDINI_ID, 0);
									if (tmp < new.ID) then
									  tmp = GEN_ID(GEN_TBORDINI_ID, new.ID-tmp);
								  END
								END!!
								SET TERM ; !! 