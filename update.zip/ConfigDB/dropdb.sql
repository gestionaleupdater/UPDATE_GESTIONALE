						DROP TABLE tbSostituito;
						DROP TABLE tbInventario;
                        DROP TABLE tbRitirato;
                        DROP TABLE tbOrdini;
                        DROP TABLE tbRicambi;
                        DROP TABLE tbNegozi;
                        DROP TABLE tbClienti;
                        DROP TABLE tbUtenti;
						
						DROP GENERATOR GEN_TBSOSTITUITO_ID;
						
                        DROP GENERATOR GEN_TBINVENTARIO_ID;
                        
                        DROP GENERATOR GEN_TBRITIRATO_ID;
                        
                        DROP GENERATOR GEN_TBORDINI_ID;

                        DROP GENERATOR GEN_TBNEGOZI_ID;

                        DROP GENERATOR GEN_TBCLIENTI_ID;